from sqlalchemy.orm import Session
from typing import Dict


from . import models
from ..auth.models import User
from .nermodels import *
from nerimplementations import Cluener

model_cache : Dict[str, NERModel] = {}

def get_ner_model(model_name : str) -> NERModel:
    if model_name in model_cache:
        return model_cache[model_name]
    
    if model_name == 'cluener':
        model_cache['cluener'] = Cluener().model
        return model_cache['cluener']

    raise ValueError(f"Model {model_name} not found in registry.")
    
def insert_autolabels(db : Session, current_user : User, request : schemas.CreateAutoLabel) -> models.AutoLabel:


def autogenerate_labels_for_chapter_revision(db : Session, current_user : User, raw_chapter_revision_id : int) -> models.AutoLabel:
    pass